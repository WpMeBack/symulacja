public class Symulacja {
    public static void main(String[] args) {
        Gra gra = new GraMakao(4);
        gra.rozpocznijGre();
    }
}
